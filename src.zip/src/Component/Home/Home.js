import React, { Component } from 'react';
import { connect } from 'react-redux';
import { BrowserRouter, Link, Route } from 'react-router-dom';
//import axios from 'axios';
import Header from '../Header/Header';
import './Home.css';

class Home extends Component {
    constructor() {
        super();
        this.state = {
            price: '',
            pName: '',
            isError: ''
        };
        this.form = (e, param) => {
            switch (param) {
                case 'price':
                    this.setState({ price: e.target.value });
                    break;
                case 'pName':
                    this.setState({ pName: e.target.value });
                    break;
                    default:
                    break;
            }
        };
        this.submit = () => {
            alert("hi");
            const price = this.state.price;
            const pName = this.state.pName;
            if (!price && !pName){
                this.setState({isError:'Please enter Username and password'});
            }
            else if (typeof Storage !== 'undefined') {
            this.props.history.push('/update');
               // this.props.history.push('/productlist');
            }
        };
        this.onEnterPress = (e) => {
            if (e.which === 13){
               this.submit();

            }
        };
    }
    render() {
        return (
              <main className="additems">
              <Header/>
              {console.log(this.props.username)}
              <h5> Username : { this.props.username } </h5>
              Product Name:  <input
                    className="item-input"
                    placeholder="pName"
                    type="text"
                    autoFocus
                    value={this.state.pName}
                    onChange={(e) => this.form(e, 'pName')}
                    onKeyPress={this.onEnterPress}
                />
              Product price :  <input
                    className="item-input"
                    placeholder="price"
                    type="text"
                    value={this.state.price}
                    onChange={(e) => this.form(e, 'price')}
                    onKeyPress={this.onEnterPress}
                />
                <div className="login_error">{ this.state.isError }</div>
                <button className="login_btn" type="button" onClick={(e) => this.submit(e)}>Login</button>

            </main>
        );
    }
}

export default Home;
