import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import './Header.css';
const Update = (props) => (
    <header className="header">
        <div className="header_logo">Your shopping</div>
        <div className="header-user">
        <label> Name </label>
        <p>Welcome {this.props.pName} </p>
        <label> Price </label>
        <p> {props.price}</p>

        <Link className="cart" to="/cart"> Cart </Link>
        </div>
    </header>
);
