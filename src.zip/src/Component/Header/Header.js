import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import './Header.css';
const Header = (props) => (
    <header className="header">
        <div className="header_logo">Your shopping</div>
        <div className="header-user">
        Welcome {props.userName}
        {console.log(this.props)}
        <Link className="cart" to="/cart"> Cart </Link>
        </div>
    </header>
);


//const mapStateToProps = (state) => (
  //  {
    //    userName: state.login.userName ? state.login.userName : 'Guest'
    //}
//);
//export default connect(mapStateToProps)(Header);
export default Header;
